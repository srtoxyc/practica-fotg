CREATE VIEW CharactersGame as
select ROW_NUMBER() OVER() as id, name, description, attack, defense, accuracy, life, ether, movement, image, abilityName, abilityDesc from Characters where inGame = 'true';

