CREATE VIEW MapsGame as
select ROW_NUMBER() OVER() as id, name, description, image from Places;

