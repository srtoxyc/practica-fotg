CREATE VIEW ItemsGame as
select ROW_NUMBER() OVER() as id, name, description, rawAttack, rawDefense, rawAccuracy, rawLife, rawEther, rawMovement, percentAttack, percentDefense, percentAccuracy, percentLife, percentEther, percentMovement, image from Items;

